package kz.edu.nu.cs.se;

public class PaidState extends State {
    public PaidState(VendingMachine vendingMachine) {
        super();
        this.vendingMachine=vendingMachine;
    }
    public void insertCoin(int coin){
        vendingMachine.balance+=coin;
    }

    public int refund(){
        int bal=vendingMachine.balance;
        vendingMachine.balance=0;
        vendingMachine.setCurrentState(vendingMachine.idle);
        return bal;
    }

    public int vend(){
        vendingMachine.balance-=200;
        int ref=vendingMachine.balance;
        vendingMachine.balance=0;
        vendingMachine.setCurrentState(vendingMachine.idle);
        return ref;
    }
}
