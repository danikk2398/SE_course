package kz.edu.nu.cs.se;

public class IdleState extends State {
    public IdleState(VendingMachine vendingMachine) {
        super();
        this.vendingMachine=vendingMachine;

    }
    public void insertCoin(int coin){
        vendingMachine.balance+=coin;
        vendingMachine.setCurrentState(vendingMachine.enteringCoins);
    }

    public int refund(){
        vendingMachine.balance=0;
        return vendingMachine.balance;
    }

    public int vend(){
        throw new IllegalStateException();
    }
}
