package kz.edu.nu.cs.se;

public class EnteringCoinsState extends State {
    public EnteringCoinsState(VendingMachine vendingMachine) {
        super();
        this.vendingMachine=vendingMachine;
    }
    public void insertCoin(int coin){
        vendingMachine.balance+=coin;
        if(vendingMachine.balance>=200){
            vendingMachine.setCurrentState(vendingMachine.paid);
        }
    }

    public int refund(){
        int bal=vendingMachine.balance;
        vendingMachine.balance=0;
        vendingMachine.setCurrentState(vendingMachine.idle);
        return bal;
    }

    public int vend(){
        throw new IllegalStateException();
    }
}
