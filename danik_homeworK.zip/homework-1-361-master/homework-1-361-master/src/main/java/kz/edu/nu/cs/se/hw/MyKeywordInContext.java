package kz.edu.nu.cs.se.hw;


import java.io.*;
import java.util.*;

public class MyKeywordInContext implements KeywordInContext {
    // TODO Auto-generated constructor stub

    String pathstring;
    String htmlname;

    ArrayList<Indexable> kwic=new ArrayList<Indexable>();
    ArrayList<Indexable> list=new ArrayList<Indexable>();
    ArrayList<Indexable> keyindex=new ArrayList<Indexable>();
    ArrayList<String> txtline=new ArrayList();

    public MyKeywordInContext(String name, String pathstring) {
        this.pathstring=pathstring;
        this.htmlname=name+".html";
    }

    @Override
    public int find(String word) {
        // TODO Auto-generated method stub
        for(int i=0;i<list.size();i++){
            if(word.toLowerCase().equals(list.get(i).getEntry().toLowerCase())){
                return list.get(i).getLineNumber();
            }
        }
        return -1;
    }

    @Override
    public Indexable get(int i) {
        Indexable item=null;
        // TODO Auto-generated method stub
        for(int k=0;k<list.size();k++){
            if(i==list.get(k).getLineNumber()){
                item=list.get(k);
                break;
            }
        }
        return item;
    }

    @Override
    public void txt2html() {
        try {
            BufferedReader txtfile = new BufferedReader(new FileReader(pathstring));
            BufferedWriter htmlfile = new BufferedWriter(new FileWriter(htmlname));
            String temp = "";
            String txtfiledata = "";
            htmlfile.write("<!DOCTYPE html>");
            htmlfile.newLine();
            htmlfile.write("<html><head><meta charset=\"UTF-8\"></head><body>");
            htmlfile.newLine();
            htmlfile.write("<div>");
            htmlfile.newLine();
            int linenum = 1;
            while ((txtfiledata = txtfile.readLine()) != null) {
                htmlfile.write(txtfiledata);
                htmlfile.write("<span id=\"line_"+linenum+"\">&nbsp&nbsp["+linenum+"]</span><br>");
                linenum++;
                htmlfile.newLine();
            }
            htmlfile.write("</div></body></html>");
            htmlfile.close();
            txtfile.close();
        }
        catch (Exception e) {}
    }

    @Override
    public void indexLines() throws IOException {
        // TODO Auto-generated method stub
        //remove пyктуация, аррэй оф стрингс делим линии на слова,
        //stop words add to list and use contain
        //если нет в стопвордс создаем индексабл обьект и пишем слово и индекс
        // айтемс добавляем в новый лист и сосын біз collections.sort(list) деп жазамыз
 /*       BufferedReader txtfile = new BufferedReader(new FileReader(pathstring));
        BufferedReader stopfile = new BufferedReader(new FileReader("C:\\Users\\Dinara\\Desktop\\homework-1-361-master\\homework-1-361-master\\src\\main\\java\\kz\\edu\\nu\\cs\\se\\hw\\stop.txt"));
        String stopfiledata;
        String[] stopValues=null;
        while ((stopfiledata = stopfile.readLine()) != null) {
            stopValues = stopfiledata.split(" ");
        }
        List<String> nl=Arrays.asList(stopValues);
        String txtfiledata;
        String[] lineValues=null;
        while ((txtfiledata = txtfile.readLine()) != null) {
            txtfiledata = txtfiledata.replaceAll("\\p{P}", "");
            lineValues = txtfiledata.split(" ");
        }

        for (int i=0;i<lineValues.length;i++){
            if (nl.contains(lineValues[i].toLowerCase())){
                continue;
            }
            MyIndexable keywords=new MyIndexable(lineValues[i],i);
            keyindex.add(keywords);

            Collections.sort(keyindex);
        }
        //тхт файл линияларын эррэйлистка салам

        //create KWIC arraylist контэйнит создердин лайн намеберларын по очереди с устиде жасалган тхт файлдан алып салам
        //пока list with items ne zakonchitsya
        String line=null;
        String[] lines=null;
        while ((line=txtfile.readLine())!=null){
            lines = line.split("\\r?\\n");
        }
        int k=1;
        if (lines == null) throw new AssertionError();
        for(String oneline:lines){
            k++;
            kwic.add(new MyIndexable(oneline,k));
        }


*/
        BufferedReader txtfile = new BufferedReader(new FileReader(pathstring));
        BufferedReader stopfile = new BufferedReader(new FileReader("C:\\Users\\Dinara\\Desktop\\homework-1-361-master\\homework-1-361-master\\src\\main\\java\\kz\\edu\\nu\\cs\\se\\hw\\stop.txt"));
        String stopfiledata;
        String[] stopValues=null;
        while ((stopfiledata = stopfile.readLine()) != null) {
            stopValues = stopfiledata.split(" ");
        }
        assert stopValues != null;
        List<String> nl=Arrays.asList(stopValues);
        String oneline=null;
        String[] words=null;
        int i=1;
        while((oneline=txtfile.readLine())!=null){
            this.txtline.add(oneline);
            oneline=oneline.replaceAll("\\p{P}","");
            words=oneline.split(" ");
            for(String word:words){
                word=word.toLowerCase();
                if(nl.contains(word)){continue;}
                Indexable newobj=new MyIndexable(word,i);
                this.keyindex.add(newobj);
                Collections.sort(this.keyindex);
            }
            i++;
        }

    }

    @Override
    public void writeIndexToFile() throws IOException {
        // TODO Auto-generated method stub
        //находим слова в квик и апперкейс
        //создаем квик хтмл, пишем линии и добавляем в кейвордс сслыки
        BufferedReader txtfile = new BufferedReader(new FileReader(pathstring));
        BufferedWriter bw=new BufferedWriter(new FileWriter("kwic-frankenstein.html"));
        bw.write("<!DOCTYPE html>");
        bw.newLine();
        String line=null;
        bw.write("<html><head><meta charset=\"UTF-8\"></head><body><div style=\"text-align:center;line-height:1.6\">");
        bw.newLine();
        String linenum;
        int k=0;
        while(k<keyindex.size()){
            line=txtline.get(k).toString().replaceAll(kwic.get(k).getEntry(),"<a href=\""+txtfile+"#line_"
                    +keyindex.get(k).getLineNumber()+"\">"+kwic.get(k).getEntry().toUpperCase()+"</a>");
            line=line+"<br>";
            bw.write(line);
            bw.newLine();
            k++;
        }
        bw.write("</div></body></html>");
        bw.close();
    }

}