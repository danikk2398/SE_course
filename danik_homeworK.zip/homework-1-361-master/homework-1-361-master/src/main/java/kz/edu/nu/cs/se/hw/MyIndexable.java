package kz.edu.nu.cs.se.hw;

public class MyIndexable implements Indexable {
    
    private String word;
    private int index;
    MyIndexable (String word,int index){
        this.word=word;
        this.index=index;
    }
    public int compareTo(Indexable o) {
        if (this.word.compareTo(o.getEntry()) == 0) {
            if (this.index > o.getLineNumber()) {
                return 1;
            } else if (this.index < o.getLineNumber()) {
                return -1;
            }
        }

        return this.word.compareTo(o.getEntry());

    }


    @Override
    public String getEntry() {
        return word;
    }

    public int getLineNumber() {
        return index;
    }

}
