package kz.edu.nu.cs.se.hw;

public enum Steps {
    DRAW, MELD, DISCARD, RUMMY, WAITING, FINISHED;
}
