package kz.edu.nu.cs.se.hw;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Timestamp;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.DELETE;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Response;

import com.google.gson.Gson;

@Path("/items")
public class ListItemsService {
    
    private List<String> list = new CopyOnWriteArrayList<String>();
    public ListItemsService() {
        for (int i = 0; i < 20; i++) {
            Timestamp ts;
            ts = new Timestamp(System.currentTimeMillis());
            String date=ts.toString();
            list.add(date+" Entry " + String.valueOf(i));
        }

        Collections.reverse(list);
    }

    @GET
    public Response getList() {
        Gson gson = new Gson();

        return Response.ok(gson.toJson(list)).build();
    }
    
    @GET
    @Path("{id: [0-9]+}")
    public Response getListItem(@PathParam("id") String id) {
        int i = Integer.parseInt(id);
        
        return Response.ok(list.get(i)).build();
    }

    @DELETE
    @Path("{id: [0-9]+}")
    public Response deleteListItem(@PathParam("id") String id){
        int i=Integer.parseInt(id);
        list.remove(i);
        return Response.ok().build();
    }
    @POST
    public Response postListItem(@FormParam("newEntry") String entry) {
        if(entry.matches("[ ]*")){
            return Response.status(404).build();
        }
        Timestamp ts;

        ts = new Timestamp(System.currentTimeMillis());
        String date=ts.toString();
        list.add(0, date+"  "+entry);
        
        return Response.ok().build();
    }

   @DELETE
    public Response clearList(){
        list.clear();
        return Response.ok().build();
   }


}
